Task list for ICTFax
=========================

Following are our recommendations and task list to improve overall user experience with ICTFax.

### Cover Page

A cover page to be added to each and every fax which will include the Title and description of the Document, user details, Date and time and the recipent information. Before adding the document user will be asked to add some details like

- Document Title
- Description
- User Details
- Recipent Information

It will then generate a cover page of this information and will append it as a page in the document. 


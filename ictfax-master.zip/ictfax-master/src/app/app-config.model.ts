export interface IAppConfig {
  env: {
    name: string;
  };
  apiServer: {
    url: string;
  };
}
